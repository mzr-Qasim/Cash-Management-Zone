import sqlite3


def connect():
	conn=sqlite3.connect("Database//Gaming_Zone_Database.db")
	cur=conn.cursor()
	cur.execute("CREATE TABLE IF NOT EXISTS GamingZone (id INTEGER PRIMARY KEY, name REAL, loan INTEGER, dateofloan TEXT, timeofcharges TEXT NOT NULL)")
	conn.commit()
	conn.close()

def insert(name,loan,dateofloan,timeofcharges):
	conn=sqlite3.connect("Database//Gaming_Zone_Database.db")
	cur=conn.cursor()
	cur.execute("INSERT INTO GamingZone VALUES (NULL,?,?,?,?)",(name,loan,dateofloan,timeofcharges))
	conn.commit()
	conn.close()

def view():
	conn=sqlite3.connect("Database//Gaming_Zone_Database.db")
	cur=conn.cursor()
	cur.execute("SELECT * FROM GamingZone")
	rows=cur.fetchall()
	conn.close()
	return rows

def search(name="", loan="", dateofloan=""):
    conn = sqlite3.connect("Database//Gaming_Zone_Database.db")
    cur = conn.cursor()
    
    # Use LOWER() to make the name search case-insensitive
    cur.execute("""
        SELECT * FROM GamingZone 
        WHERE LOWER(name) = LOWER(?) OR loan = ? OR dateofloan = ?
    """, (name, loan, dateofloan))
    
    rows = cur.fetchall()
    conn.close()
    return rows



def delete(id):
	conn=sqlite3.connect("Database//Gaming_Zone_Database.db")
	cur=conn.cursor()
	cur.execute("DELETE FROM GamingZone WHERE id=?", (id,))
	conn.commit()
	conn.close()
	
def update(id,name,loan,dateofloan):
	conn=sqlite3.connect("Database//Gaming_Zone_Database.db")
	cur=conn.cursor()
	cur.execute("UPDATE GamingZone SET name=?, loan=?, dateofloan=? WHERE id=?",(name,loan,dateofloan,id))
	conn.commit()
	conn.close()



'''def Sum_Function():
	conn=sqlite3.connect("Database//Gaming_Zone_Database.db")
	cur=conn.cursor()
	cur.execute("SELECT SUM(loan) from GamingZone")
	result=cur.fetchall()
	conn.close()'''











connect()



