import pygame 
import sqlite3
from github import Github
from github.GithubException import UnknownObjectException




def send_data_to_github(_=None):

    # Connect to SQLite database
    conn = sqlite3.connect('Database//Gaming_Zone_Database.db')
    cursor = conn.cursor()

    # Retrieve data from SQLite database
    cursor.execute("SELECT * FROM GamingZone")
    data = cursor.fetchall()

    # Generate HTML content
    html_content = f"""
<html>
<head>
    <title>eSports Gaming Zone</title>
    <style>
        td {{ padding: 5px; font-size:30px; }}  /* Add padding to create margin between columns */
        .table-container {{ display: flex; justify-content: center; }}  /* Centering the table */
        .centered {{
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;  /* Full height to center vertically */
        }}
    </style>
    <script>
        let password = "";  // Change this to your desired password

        function checkPassword() {{
            // Create a temporary input field for password
            const input = document.createElement("input");
            input.type = "password";
            input.placeholder = "Enter the password:";
            input.style.margin = "10px";  // Add margin for spacing
            document.body.appendChild(input);
            input.focus();

            // Create a button to submit the password
            const button = document.createElement("button");
            button.textContent = "Submit";
            document.body.appendChild(button);

            button.onclick = function() {{
                if (input.value !== password) {{
                    document.body.innerHTML = "<h1>Access denied.</h1>";
                }} else {{
                    document.getElementById("content").style.display = "block"; // Show the content if the password is correct
                    input.style.display = "none";  // Hide the input after successful login
                    button.style.display = "none";  // Hide the button after successful login
                }}
            }};
        }}

        window.onload = checkPassword;  // Call the function when the page loads
    </script>
</head>
<body class="centered" style="margin: 0">  <!-- Add the centered class to the body -->
    <div id="content" style="display: none;">  <!-- Initially hide the content -->
        <div class='table-container'>
            <table border='1'>
                <tr><th>ID</th><th>Name</th><th>Charges</th><th>Date</th><th>Time</th></tr>
"""

    for row in data:
        html_content += "<tr>"
        for col in row:
            html_content += f"<td>{col}</td>"
        html_content += "</tr>"

    html_content += """
                </table>
            </div>
        </div>
    </body>
    </html>
    """

    # Write HTML content to a file
    with open('Files//data.html', 'w') as f:
        f.write(html_content)

    # Upload HTML file to GitHub repository
    github_token = ""  # Replace with your GitHub token
    g = Github(github_token)
    username = ""  # Replace with your GitHub username
    repository_name = ""  # Replace with your GitHub repository name
    repo = g.get_repo(f"{username}/{repository_name}")
    branch_name = "main"  # or "master" depending on your repository's default branch
    file_path = "index.html"  # Path where you want to create the file
    commit_message = "Upload SQLite data"  # Commit message for the file creation

    try:
        # Attempt to get the file if it exists to obtain its SHA
        existing_file = repo.get_contents(file_path, ref=branch_name)
        repo.update_file(file_path, commit_message, html_content, existing_file.sha, branch=branch_name)
        print("File updated successfully on GitHub.")
        pygame.mixer.music.load("Sounds//Website_database_updated.mp3")
        pygame.mixer.music.play()


        

    except UnknownObjectException:
        # If the file doesn't exist, create it
        repo.create_file(file_path, commit_message, html_content, branch=branch_name)
        print("File uploaded successfully to GitHub.")
        pygame.mixer.music.load("Sounds//Website_database_updated.mp3")
        pygame.mixer.music.play()





  