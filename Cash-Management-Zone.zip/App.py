# Import Functions

from calendar import c
from concurrent.futures import thread
from fileinput import close
import webbrowser
import urllib.request
from tkinter import *
from tkinter.font import Font
import urllib.request
import threading
import os
from tkinter import filedialog
from PIL import Image, ImageTk
from io import BytesIO
import time
import tkinter.font
import ctypes
import Database 
import sqlite3
from datetime import datetime
from Upload_to_Website_File import send_data_to_github
from tkinter import messagebox
import pygame
import pytz
from tkinter import simpledialog

# Main Window Function

def get_password():
    root = Tk()
    root.withdraw()  # Hide the root window
    password = simpledialog.askstring("Input", "Enter the password:")
    root.destroy()  # Close the Tkinter window
    return password


def opentheapp():

# Window Setting
    root =  Tk()
    root.wm_attributes('-fullscreen', 'True')
    root.title("esports Gaming Zone")
    root.iconbitmap("Images//esportsicon.ico")
    cursorpath="@Cursors//mainscreencursor.cur"
    root[ 'cursor' ] = cursorpath


    
  






    mainscreenselectcursor="@Cursors//mainscreenselectcursor.cur"
    
    width = 1200 # Width 
    height = 800 # Height

    w=width
    h=height
    screen_width = root.winfo_screenwidth()  # Width of the screen
    screen_height = root.winfo_screenheight() # Height of the screen

    global x
    x = (screen_width/2) - (width/2) # 300
    global y
    y = (screen_height/2) - (height/2) # 140
 
    middlecanvas=x*2.2

    sidecanvas=width-middlecanvas
    newsidecanvas=sidecanvas/2

    anothernewidcanvas=newsidecanvas+40
    # 244
    new=y*2
    new2=x*2.2

# Background Image
    img=PhotoImage(file="Images//New.png")
    Background=Label(root,image=img,bd=0)
    Background.place(relx=0,rely=0,anchor=NW)

    bgcolorforwidgets="black"




# Title Bar Button Animations

    def close_button_e(e):
        closebutton["bg"]="red"
        closebutton["fg"]="white"

    def close_button_l(e):
        closebutton["bg"]="black"
        closebutton["fg"]="white"

    def re_button_e(e):
        minimizebutton["bg"]="grey40"
        minimizebutton["fg"]="white"

    def re_button_l(e):
        minimizebutton["bg"]="grey5"
        minimizebutton["fg"]="white"




# Title Bar Button Functions
    def resizable():
        root.iconify()

    def resi(e):
        root.after(300,resizable)

    






    def Close_Window_2():
        root.destroy()

    def Close_Window(e):
        root.after(800,Close_Window_2)
       


    

    def exit_application(e):
        msg_box = messagebox.askquestion('Exit Application', 'Are you sure you want to exit the application?',icon='warning')
        if msg_box == 'yes':
            root.destroy()
        else:
            pass


   





# Title Bar Window Canvas
    
    

    global count,text 
    count=0
    text=''
    def slider():
        global text,count
        if count==len(sliderlabel):
            count=0
            text=''
        text=text+sliderlabel[count]
        TitlebarLabel.config(text=text)
        count+=1
        TitlebarLabel.after(220,slider) 
        





    canvastitlebar = Canvas(root,height=anothernewidcanvas*0.3,width=1920,bg='black',highlightthickness=0,bd=0)
    canvastitlebar.place(relx=0,rely=0,anchor=NW)

    sliderlabel= "eSports GAMING ZONE"


    
    nexusfont=Font(family="Audiowide",size=35)
    TitlebarLabel=Label(canvastitlebar,text=sliderlabel,fg="#52e4fd",bg="black",font=nexusfont)
    TitlebarLabel.place(relx=.5,rely=.5,anchor=CENTER)
    slider()


    '''canvasdownbar = Canvas(root,height=anothernewidcanvas*0.2,width=1920,bg='grey1',highlightthickness=0,bd=0)
    canvasdownbar.place(relx=0,rely=.955,anchor=NW)

    DownbarLabel=Label(canvasdownbar,text="Nexus Gaming Zone Commercial Market Satellite Town Post Plaza",fg="white",bg="grey1",font="Roboto 20 bold")
    DownbarLabel.place(relx=.5,rely=.5,anchor=CENTER)'''



# Title Bar Buttons
    minimizebutton=Button(canvastitlebar,text="-",fg="white",bg="grey5",width=3,bd=0,font=("Arial 14  "),cursor=mainscreenselectcursor)
    minimizebutton.place(relx=.98,rely=0,anchor=NE)
    minimizebutton.bind("<Button-1>",resi)
    minimizebutton.bind('<Return>',resi)


    minimizebutton.bind("<Enter>",re_button_e)
    minimizebutton.bind("<Leave>",re_button_l)

    global closebutton
    closebutton=Button(canvastitlebar,text="x",fg="white",bg="black",width=3,bd=0,font=("Arial 14  "),cursor=mainscreenselectcursor)
    closebutton.place(relx=1,rely=0,anchor=NE)
    closebutton.bind("<Button-1>",exit_application)
    closebutton.bind('<Return>',exit_application)
    
    


    closebutton.bind("<Enter>",close_button_e)
    closebutton.bind("<Leave>",close_button_l)

   





# Side Window Canvas
    canvas20 = Canvas(root,height=1074,width=anothernewidcanvas/2,bg='black',highlightthickness=3,bd=0,highlightbackground="white")
    canvas20.place(relx=0,rely=0,anchor=NW)
    
    '''img=PhotoImage(file="Side bar.png")
    Background=Label(canvas20,image=img,bd=0)
    Background.place(relx=0,rely=0,anchor=CENTER)'''





# Window Logo
    '''logomzr=PhotoImage(file='Images//Nexus.png')
    Logo=Label(canvas20,image=logomzr,bd=0)
    Logo.place(relx=.5,rely=0.05,anchor=CENTER)'''





    logo_font=Font(family="Audiowide",size=17)
    Logo=Label(canvas20,text="eSports",font=logo_font,fg="white",bg="black",bd=0)
    Logo.place(relx=.5,rely=0.037,anchor=CENTER)








# Internet Connection

    def check_internet_connection():
        try:
            urllib.request.urlopen('http://www.google.com', timeout=1)
            return True
        except urllib.error.URLError:
            return False



# Convert images to Tkinter format
    connected_photo = PhotoImage(file="Images//Internet_Connected.png")
    disconnected_photo = PhotoImage(file="Images//No_Internet_Connection.png")

# Create a label to display the image
    image_label = Label(canvas20,borderwidth=0, highlightthickness=0)
    image_label.place(relx=.5,rely=.92,anchor=CENTER)

# Function to update the displayed image
    def update_image():
        if check_internet_connection():
            image_label.config(image=connected_photo)
        else:
            image_label.config(image=disconnected_photo)
        root.after(3000, update_image)

# Call the update_image function initially
    update_image()




    def update_date():
    # Get the current date and time
        now = datetime.now()

    # Format the date and time as a string
        '''current_time = now.strftime("%d-%m-%Y %I:%M:%S %p")'''
        current_date = now.strftime("%d-%m-%Y")
    # Update the label with the current date and time
        date_label.config(text=current_date)

    # Schedule the update_time function to run again in 1000 milliseconds (1 second)
        root.after(1000, update_date)


    def update_time():
    # Get the current date and time
        now = datetime.now()

    # Format the date and time as a string
        '''current_time = now.strftime("%d-%m-%Y %I:%M:%S %p")'''
        current_time = now.strftime("%I:%M:%S %p")
    # Update the label with the current date and time
        time_label.config(text=current_time)

    # Schedule the update_time function to run again in 1000 milliseconds (1 second)
        root.after(1000, update_time)

    '''
    midframe=Frame(canvas20,height=40,width=100,bg="red")
    midframe.place(relx=.5,rely=.5,anchor=CENTER)'''

    







    time_label =Label(canvas20, text="",fg="DarkOrange2",bg="black",font="radioland 11")
    time_label.place(relx=.5,rely=.96,anchor=CENTER)

    date_font= Font(family="Audiowide",size=8,weight="normal")
    date_label =Label(canvas20, text="",fg="white",bg="black",font=date_font)
    date_label.place(relx=.5,rely=.981,anchor=CENTER)




   


# Center Window Canvas
    '''canvas21 = Canvas(root,height=y*3.5,width=x*1,bg='black',highlightthickness=0)
    canvas21.place(relx=.5,rely=.5,anchor=CENTER)
'''


# Student Record Binding Fucntion
    def StudentRecord_e(e):
        StudentRecord["bg"]="white"
        StudentRecord["fg"]="black"
    




    def StudentRecord_l(e):
        StudentRecord["bg"]="black"
        StudentRecord["fg"]="white"

# Update Record Binding Fucntion
    
# New Admission Binding Fucntion

    def NewAdmission_e(e):
        NewAdmission["bg"]="white"
        NewAdmission["fg"]="black"
    
    def NewAdmission_l(e):
        NewAdmission["bg"]="black"
        NewAdmission["fg"]="white"




# Upload To Website Binding Functions
    def Upload_to_Website_e(e):
        Upload_to_Website_Button["bg"]="white"
        Upload_to_Website_Button["fg"]="black"

    def Upload_to_Website_l(e):
        Upload_to_Website_Button["bg"]="black"
        Upload_to_Website_Button["fg"]="white"


    def Upload_to_Website_e(e):
        Upload_to_Website_Button["bg"]="white"
        Upload_to_Website_Button["fg"]="black"

    def Upload_to_Website_l(e):
        Upload_to_Website_Button["bg"]="black"
        Upload_to_Website_Button["fg"]="white"


# Button Commands
  

# Labels
  

# Main Window Font
    Mainfont="Roboto 14 bold"
    
# Main Window Buttons
    

    def Search_button_e(e):
        Search["bg"]="white"
        Search["fg"]="black"

    def Search_button_l(e):
        Search["bg"]="black"
        Search["fg"]="white"


    

    def addedsuccessfullyreset():
        addedsuccessfully.configure(text="",bg="white",fg="white")


    def Locked_Delete():
        pass


    def Locked_Update(e):
        pass

    def disable_empty_field():
        Emptyfieldlabel.configure(text="")    

    def Search_Student_Record(e):
        try:
            pygame.mixer.music.load("Sounds//Inside_Window_Buttons.mp3")
            pygame.mixer.music.play()

            search_term = m32.get()

            # Validate the input
            if len(search_term) < 3:
                if len(search_term) == 0:
                    Emptyfieldlabel.configure(text="Empty Field")
                else:
                    Emptyfieldlabel.configure(text="Invalid Name")
                m32.after(2000, disable_empty_field)
                pygame.mixer.music.load("Sounds//Records_Denied1.mp3")
                pygame.mixer.music.play()
                List.delete(0, END)  # Clear the list if invalid input
                return  # Exit the function early

            # Clear previous results
            List.delete(0, END)

            # Perform the search
            results = Database.search(search_term)

            # Check if any results were returned
            if not results:
                Emptyfieldlabel.configure(text="Invalid Name")
                m32.after(2000, disable_empty_field)
                pygame.mixer.music.load("Sounds//Records_Denied1.mp3")
                pygame.mixer.music.play()
            else:
                # Insert matching records into the list
                for row in results:
                    List.insert(END, row)

        except Exception as e:
            print("Error:", e)  # Print the exception for debugging



    

    def View_All_Student_Record():
        try:
            pygame.mixer.music.load("Sounds//Access_Granted.mp3")
            pygame.mixer.music.play()
        
        
        

            conn=sqlite3.connect("Database//Gaming_Zone_Database.db")
            cur=conn.cursor()
            cur.execute("SELECT SUM(loan) FROM GamingZone;")
            result = cur.fetchone()[0]
            Total_Amount_Entry.config(text=f"{result} Rs")




            Unlock_View_Records_Entry.delete(0,END)
            List.delete(0,END)
        
            for row in Database.view():
                List.insert(END,row)

        except:
            pass
        


    
    def Hide_Loan_Record(e):
        
        try:
            pygame.mixer.music.load("Sounds//Inside_Window_Buttons.mp3")
            pygame.mixer.music.play()

            Total_Amount_Entry.config(text="")



            List.delete(0,END)
            UpdateNameEntryBox.delete(0,END)
            UpdateLoanEntryBox.delete(0,END)
            UpdateDateofLoanEntryBox.delete(0,END)
            UpdateNameEntryBox.config(state="disabled")
            UpdateLoanEntryBox.config(state="disabled")
            UpdateDateofLoanEntryBox.config(state="disabled")
            Delete_Selected.config(command=Locked_Delete)
            Update_Button.bind("<Button-1>",Locked_Update)
            Update_Button.bind("<Return>",Locked_Update)
            m32.delete(0,END)
        except:
            pass
       


    def SubmitLatestCustomer(e):
        try:
            customer_name = NewCustomerNameEntryBox.get().strip()
            customer_loan = NewCustomerLoanEntryBox.get().strip()
            date_of_loan = NewCustomerdateofLoanEntryBox.get().strip()
            if len(NewCustomerNameEntryBox.get()) <= 2:
                pass
            elif len(NewCustomerLoanEntryBox.get()) <= 1:
                pass
            elif len(NewCustomerdateofLoanEntryBox.get()) <= 2:
                pass
        
            else :
                timezone = pytz.timezone('Asia/Karachi')
                formatted_time = datetime.now(timezone)
                Time = formatted_time.strftime("%I:%M:%S %p")
                current_time = Time.strip()
                Database.insert(customer_name, customer_loan, date_of_loan, current_time)
                SubmitNewCustomer.after(50,NewCustomerNameEntryBox.delete(0,END))
                SubmitNewCustomer.after(50,NewCustomerLoanEntryBox.delete(0,END))
                SubmitNewCustomer.after(50,NewCustomerdateofLoanEntryBox.delete(0,END))
                addedsuccessfully.configure(text="Added Successfully!",bg="black",fg="white")
                addedsuccessfully.after(2000,addedsuccessfullyreset)
                pygame.mixer.music.load("Sounds//New_Record.mp3")
                pygame.mixer.music.play()

        except:
            pass

   



    def sp(e):

# Window
   
            
        pygame.mixer.init()

        pygame.mixer.music.load("Sounds//Button_Effect.mp3")
        pygame.mixer.music.play()




        sp=Tk()
        sp.title("Customer Record")
        sp.attributes("-fullscreen",True)
        sp.configure(bg="black")
        sp.iconbitmap("Images//esportsicon.ico")
        sp.after(1, lambda: sp.focus_force())
        customerrecordcursorpath="@Cursors//mainscreencursor.cur"
        sp[ 'cursor' ] = customerrecordcursorpath

        customerrecordtcursor="@Cursors//mainscreenselectcursor.cur"
        customerrecordEntrycursor="@Cursors//Entryselect.cur"



 # Labels
        

        SearchStudentLabel=Label(sp,text="Customer Record",bg="black",fg="white",font=("roboto 22 bold"))
        SearchStudentLabel.place(relx=.5,rely=.04,anchor=CENTER)
        
        


        StudentName=Label(sp,text="Customer Name",font=("roboto 12 bold"),bg="black",fg="white")
        StudentName.place(relx=.3,rely=.1,anchor=CENTER)
        
  

        global DeleteSelectedList
        def DeleteSelectedList():
            pygame.mixer.music.load("Sounds//Inside_Window_Buttons.mp3")
            pygame.mixer.music.play()
    
            try:
                Database.delete(selected_tuple[0])
            except:
                pass
            



# Buttons
        
        def Delete_Selected_button_e(e):
            Delete_Selected["bg"]="white"
            Delete_Selected["fg"]="black"
        
        def Delete_Selected_button_l(e):
            Delete_Selected["bg"]="black"
            Delete_Selected["fg"]="white"


        def Back_Button_Cutomer_Record_e(e):
            Back["bg"]="white"
            Back["fg"]="black"

        def Back_Button_Cutomer_Record_l(e):
            Back["bg"]="black"
            Back["fg"]="white"

        def Update_Button_e(e):
            Update_Button["bg"]="white"
            Update_Button["fg"]="black"

        def Update_Button_l(e):
            Update_Button["bg"]="black"
            Update_Button["fg"]="white"


        def View_All_e(e):
            View_All["bg"]="white"
            View_All["fg"]="black"

        def View_All_l(e):
            View_All["bg"]="black"
            View_All["fg"]="white"





        def Update_Changings(e):
                
            
            pygame.mixer.music.load("Sounds//Inside_Window_Buttons.mp3")
            pygame.mixer.music.play()

            try:
                Database.update(selected_tuple[0],UpdateNameEntryBox.get(),UpdateLoanEntryBox.get(),UpdateDateofLoanEntryBox.get())
            except:
                pass
          

        









        global View_All
        
        UpdateLoanLabel=Label(sp,text="Charges",font=("roboto 12 bold"),bg="black",fg="white")
        UpdateLoanLabel.place(relx=.45,rely=.15,anchor=CENTER)

        global m32
        m32=Entry(sp,width=50,font=("roboto 16"),cursor=customerrecordEntrycursor)
        m32.place(relx=.5,rely=.1,anchor=CENTER)
        m32.configure(bg="black", insertbackground='white',foreground="white")
        m32.focus_set()
        m32.bind('<Return>', Search_Student_Record)
        


        

        



        global Search
        Search=Button(sp,text="Search",width=10,font=("roboto 12 bold"),bg="black",fg="white",cursor=customerrecordtcursor)
        Search.place(relx=.7,rely=.1,anchor=CENTER)
        Search.bind("<Button-1>",Search_Student_Record)
        Search.bind('<Return>',Search_Student_Record)
        

        Search.bind("<Enter>",Search_button_e)
        Search.bind("<Leave>",Search_button_l)
        
        global Emptyfieldlabel
        Emptyfieldlabel=Label(sp,text="",bg="black",fg="red",font=("roboto 16"))
        Emptyfieldlabel.place(relx=.77,rely=.1,anchor=CENTER)
        

        global UpdateNameEntryBox
        UpdateNameEntryBox=Entry(sp,width=25,font=("roboto 14"),cursor=customerrecordEntrycursor)
        UpdateNameEntryBox.place(relx=.23,rely=.15,anchor=CENTER)
        UpdateNameEntryBox.bind("<Return>", Update_Changings)
        UpdateNameEntryBox.config(state="disabled")
        


        global UpdateLoanEntryBox
        UpdateLoanEntryBox=Entry(sp,width=10,font=("roboto 14"),cursor=customerrecordEntrycursor)
        UpdateLoanEntryBox.place(relx=.5,rely=.15,anchor=CENTER)
        UpdateLoanEntryBox.bind("<Return>", Update_Changings)
        UpdateLoanEntryBox.config(state="disabled")


        global UpdateDateofLoanEntryBox
        UpdateDateofLoanEntryBox=Entry(sp,width=10,font=("roboto 14"),cursor=customerrecordEntrycursor)
        UpdateDateofLoanEntryBox.place(relx=.7,rely=.15,anchor=CENTER)
        UpdateDateofLoanEntryBox.bind("<Return>", Update_Changings)
        UpdateDateofLoanEntryBox.config(state="disabled")


   
        global Update_Button
        Update_Button=Button(sp,text="Update",width=12,font=("roboto 13 bold"),fg="white",bg="black",cursor=customerrecordtcursor)
        Update_Button.place(relx=.841,rely=.15,anchor=CENTER)
        
        Update_Button.bind("<Button-1>",Locked_Update)
        Update_Button.bind("<Return>",Locked_Update)
        


        Update_Button.bind("<Enter>",Update_Button_e)
        Update_Button.bind("<Leave>",Update_Button_l)
        
        


        UpdateNameLabel=Label(sp,text="Name",font=("roboto 12 bold"),bg="black",fg="white")
        UpdateNameLabel.place(relx=.135,rely=.15,anchor=CENTER)
      

        



        UpdateDateofLoanLabel=Label(sp,text="Date",font=("roboto 12 bold"),bg="black",fg="white")
        UpdateDateofLoanLabel.place(relx=.65,rely=.15,anchor=CENTER)
     
        
        def Unlock_View_Records(e):
            if Unlock_View_Records_Entry.get()=="123":
                Unlock_View_Records_Entry.after(10,View_All_Student_Record)
                
            else:
                pygame.mixer.music.load("Sounds//Records_Denied.mp3")
                pygame.mixer.music.play()



        Password_Label=Label(sp,text="Pass",font=("roboto 12 bold"),bg="black",fg="white")
        Password_Label.place(relx=.133,rely=.21,anchor=CENTER)

        

        global Unlock_View_Records_Entry
        Unlock_View_Records_Entry=Entry(sp,width=25,font=("roboto 14"),show="X",cursor=customerrecordEntrycursor)
        Unlock_View_Records_Entry.place(relx=.23,rely=.21,anchor=CENTER)
        Unlock_View_Records_Entry.bind('<Return>', Unlock_View_Records)



        View_All=Button(sp,text="View All Records",font=("roboto 12 bold"),bg="black",fg="white",cursor=customerrecordtcursor)
        View_All.place(relx=.35,rely=.21,anchor=CENTER)
        View_All.bind("<Button-1>",Unlock_View_Records)
        View_All.bind('<Return>',Unlock_View_Records)
       

  


        






        View_All.bind("<Enter>",View_All_e)
        View_All.bind("<Leave>",View_All_l)

        


        def Hide_All_e(e):
            Hide["bg"]="white"
            Hide["fg"]="black"

        def Hide_All_l(e):
            Hide["bg"]="black"
            Hide["fg"]="white"




        


        


















        Hide=Button(sp,text="Clear",font=("roboto 12 bold"),bg="black",fg="white",cursor=customerrecordtcursor)
        Hide.place(relx=.41,rely=.21,anchor=CENTER)
        Hide.bind("<Enter>",Hide_All_e)
        Hide.bind("<Leave>",Hide_All_l)


        Hide.bind("<Button-1>", Hide_Loan_Record)
        Hide.bind('<Return>', Hide_Loan_Record)


    











        global Delete_Selected
        Delete_Selected=Button(sp,text="Delete Selected",font=("roboto 12 bold"),bg="black",fg="white",cursor=customerrecordtcursor,command=Locked_Delete)
        Delete_Selected.place(relx=.841,rely=.21,anchor=CENTER)
        Delete_Selected.bind("<Enter>",Delete_Selected_button_e)
        Delete_Selected.bind("<Leave>",Delete_Selected_button_l)



      



        def SpDestroy(e):
            pygame.mixer.music.load("Sounds//Inside_Window_Buttons.mp3")
            pygame.mixer.music.play()
            Back.after(10,sp.destroy)


        


        Back=Button(sp,text="Back",width=10,font=("roboto 12 bold"),fg="white",bg="black",cursor=customerrecordtcursor)
        Back.place(relx=.5,rely=.9,anchor=CENTER)
        Back.bind("<Button-1>",SpDestroy)
        Back.bind('<Return>',SpDestroy)


        Back.bind("<Enter>",Back_Button_Cutomer_Record_e)
        Back.bind("<Leave>",Back_Button_Cutomer_Record_l)

        
        















       

        global Total_Amount_Entry
        

        Total_Amount_Entry_Label=Label(sp,text="Total:",font=("roboto 14 bold"),fg="white",bg="black")
        Total_Amount_Entry_Label.place(relx=.137,rely=.79,anchor=CENTER)


        

        Total_Amount_Entry=Label(sp,text="",font=("roboto 14 bold"),fg="white",bg="black")
        Total_Amount_Entry.place(relx=.186,rely=.79,anchor=CENTER)
      



# Entry Boxes
   
        def get_selected_row(e):
            global selected_tuple
            try:
                global index
                
                index=List.curselection()[0]
                selected_tuple=List.get(index)
            
                UpdateNameEntryBox.config(state="normal")
                UpdateNameEntryBox.delete(0,END)
                UpdateNameEntryBox.insert(END,selected_tuple[1])

                UpdateLoanEntryBox.config(state="normal")
                UpdateLoanEntryBox.delete(0,END)
                UpdateLoanEntryBox.insert(END,selected_tuple[2])
                
                UpdateDateofLoanEntryBox.config(state="normal")
                UpdateDateofLoanEntryBox.delete(0,END)
                UpdateDateofLoanEntryBox.insert(END,selected_tuple[3])
                
                Delete_Selected.config(command=DeleteSelectedList)
                
                Update_Button.bind("<Button-1>",Update_Changings)
                Update_Button.bind("<Return>",Update_Changings)

            except:
                pass
          
           



     
    
        global List
        List=Listbox(sp,width=80,height=15,cursor=customerrecordtcursor,font=("roboto 24"))
        List.place(relx=.5,rely=.5,anchor=CENTER)

        Scroll=Scrollbar(List,cursor='hand2')
        Scroll.place(relx=.995,rely=.5,anchor=CENTER)

        List.configure(yscrollcommand=Scroll.set)
        Scroll.configure(command=List.yview)

        List.bind("<<ListboxSelect>>",get_selected_row)

        

 
        











        mainloop()

    def NewSAdmission(e):

        
        pygame.mixer.music.load("Sounds//Button_Effect.mp3")
        pygame.mixer.music.play()


        NewCustomer=Tk()
        NewCustomer.title("Add Record")
        NewCustomer.attributes("-fullscreen",True)
        NewCustomer.configure(bg="black")
        NewCustomer.iconbitmap("Images//esportsicon.ico")
        NewCustomer.after(1, lambda: NewCustomer.focus_force())
        Addrecordcursorpath="@Cursors//mainscreencursor.cur"
        NewCustomer[ 'cursor' ] = Addrecordcursorpath

        Addrecordtcursor="@Cursors//mainscreenselectcursor.cur"
        AddrecordEntrycursor="@Cursors//Entryselect.cur"



        NewCustomer_Canvas = Canvas(NewCustomer,height=y*3.5,width=x*2,bg='white',highlightthickness=0)
        NewCustomer_Canvas.place(relx=.5,rely=.5,anchor=CENTER)


       



 # Labels

        NewCustomerLabel=Label(NewCustomer,text="Enter Customer Details",bg="black",fg="white",font=("roboto 22 bold"))
        NewCustomerLabel.place(relx=.5,rely=.04,anchor=CENTER)
        
        
        NexusGamingZoneLabel=Label(NewCustomer_Canvas,text="eSports Gaming Zone",font=("roboto 20 bold"),bg="white",fg="black")
        NexusGamingZoneLabel.place(relx=.5,rely=.10,anchor=CENTER)
        

        Customername=Label(NewCustomer_Canvas,text="Customer Name",font=("roboto 16 bold"),bg="white",fg="black")
        Customername.place(relx=.199,rely=.30,anchor=CENTER)
        
        Customerloan=Label(NewCustomer_Canvas,text="Customer Charges",font=("roboto 16 bold"),bg="white",fg="black")
        Customerloan.place(relx=.216,rely=.40,anchor=CENTER)

        Customerdateofloan=Label(NewCustomer_Canvas,text="Date of Charges",font=("roboto 16 bold"),bg="white",fg="black")
        Customerdateofloan.place(relx=.199,rely=.50,anchor=CENTER)
        datepattern=Label(NewCustomer_Canvas,text="(dd-mm-yyyy)",font=("roboto 10 bold"),bg="white",fg="black")
        datepattern.place(relx=.199,rely=.54,anchor=CENTER)



        def NewCustomerdestroy(e):
            pygame.mixer.music.load("Sounds//Inside_Window_Buttons.mp3")
            pygame.mixer.music.play()

            BackNewCustomer.after(10,NewCustomer.destroy)

        

        def Back_New_Customer_e(e):

            BackNewCustomer["bg"]="white"
            BackNewCustomer["fg"]="black"

        def Back_New_Customer_l(e):
            BackNewCustomer["bg"]="black"
            BackNewCustomer["fg"]="white"  








    





        global NewCustomerNameEntryBox
        NewCustomerNameEntryBox=Entry(NewCustomer_Canvas,width=30,font=("roboto 16"),cursor=AddrecordEntrycursor)
        NewCustomerNameEntryBox.place(relx=.7,rely=.30,anchor=CENTER)
        NewCustomerNameEntryBox.configure(bg="black", insertbackground='white',foreground="white")
        NewCustomerNameEntryBox.focus_set()
        

        
        



        global NewCustomerLoanEntryBox
        NewCustomerLoanEntryBox=Entry(NewCustomer_Canvas,width=30,font=("roboto 16"),cursor=AddrecordEntrycursor)
        NewCustomerLoanEntryBox.place(relx=.7,rely=.40,anchor=CENTER)
        NewCustomerLoanEntryBox.configure(bg="black", insertbackground='white',foreground="white")
        
        





        global NewCustomerdateofLoanEntryBox
        NewCustomerdateofLoanEntryBox=Entry(NewCustomer_Canvas,width=30,font=("roboto 16"),cursor=AddrecordEntrycursor)
        NewCustomerdateofLoanEntryBox.place(relx=.7,rely=.50,anchor=CENTER)
        NewCustomerdateofLoanEntryBox.configure(bg="black", insertbackground='white',foreground="white")
        NewCustomerdateofLoanEntryBox.bind("<Return>", SubmitLatestCustomer)

        Or_label=Label(NewCustomer_Canvas,text="OR",font=("roboto 10 bold"),bg="white",fg="black")
        Or_label.place(relx=.7,rely=.57,anchor=CENTER)
        


        def add_currentdate(e):
            pygame.mixer.music.load("Sounds//Inside_Window_Buttons.mp3")
            pygame.mixer.music.play()

            loan_date = datetime.now()
            currentdate = loan_date.strftime("%d-%m-%Y")
            if len(NewCustomerdateofLoanEntryBox.get())>=1:
                NewCustomerdateofLoanEntryBox.delete(0,END)
                NewCustomerdateofLoanEntryBox.insert(END,currentdate)
            
            else:
                NewCustomerdateofLoanEntryBox.insert(END,currentdate)
            

      



    
        def date_button_e(e):
            datebutton["bg"]="white"
            datebutton["fg"]="black"

        def date_button_l(e):
            datebutton["bg"]="black"
            datebutton["fg"]="white"




        datebutton = Button( NewCustomer_Canvas , text = "Current Date",font=("roboto 10 bold"),bg="black",fg="white",cursor=Addrecordtcursor)
        datebutton.place(relx=.7,rely=.64,anchor=CENTER)
        datebutton.bind("<Button-1>",add_currentdate)
        datebutton.bind('<Return>',add_currentdate)

        datebutton.bind("<Enter>",date_button_e)
        datebutton.bind("<Leave>",date_button_l)

        



        def Submit_New_Cutomer_Record_e(e):

            SubmitNewCustomer["bg"]="white"
            SubmitNewCustomer["fg"]="black"

        def Submit_New_Cutomer_Record_l(e):
            SubmitNewCustomer["bg"]="black"
            SubmitNewCustomer["fg"]="white"  



        




        global SubmitNewCustomer
        SubmitNewCustomer=Button(NewCustomer_Canvas,text="Submit",width=8,bd=2,font=("roboto 12 bold"),bg="black",fg="white",cursor=Addrecordtcursor)
        SubmitNewCustomer.place(relx=.5,rely=.75,anchor=CENTER)
        SubmitNewCustomer.bind("<Button-1>",SubmitLatestCustomer)
        SubmitNewCustomer.bind('<Return>',SubmitLatestCustomer)



        SubmitNewCustomer.bind("<Enter>",Submit_New_Cutomer_Record_e)
        SubmitNewCustomer.bind("<Leave>",Submit_New_Cutomer_Record_l)
 

        


        def Clear_add_record(e):
            pygame.mixer.music.load("Sounds//Inside_Window_Buttons.mp3")
            pygame.mixer.music.play()
            if len(NewCustomerNameEntryBox.get())>=1 or len(NewCustomerLoanEntryBox.get())>=1 or len(NewCustomerdateofLoanEntryBox.get())>=1:
                NewCustomerNameEntryBox.delete(0,END)
                NewCustomerLoanEntryBox.delete(0,END)
                NewCustomerdateofLoanEntryBox.delete(0,END)
            else:
                pass
            






        def Clear_button_e(e):
            Clear_Button["bg"]="white"
            Clear_Button["fg"]="black"

        def Clear_button_l(e):
            Clear_Button["bg"]="black"
            Clear_Button["fg"]="white"  





        Clear_Button=Button(NewCustomer_Canvas,text="Clear",width=8,bd=2,font=("roboto 12 bold"),bg="black",fg="white",cursor=Addrecordtcursor)
        Clear_Button.place(relx=.7,rely=.75,anchor=CENTER)
        Clear_Button.bind("<Button-1>",Clear_add_record)
        Clear_Button.bind('<Return>',Clear_add_record)
        
        Clear_Button.bind("<Enter>",Clear_button_e)
        Clear_Button.bind("<Leave>",Clear_button_l)



        



        BackNewCustomer=Button(NewCustomer_Canvas,text="Back",width=8,bd=2,font=("roboto 12 bold"),bg="black",fg="white",cursor=Addrecordtcursor)
        BackNewCustomer.place(relx=.5,rely=.95,anchor=CENTER)
        BackNewCustomer.bind("<Button-1>",NewCustomerdestroy)
        BackNewCustomer.bind('<Return>',NewCustomerdestroy)



        BackNewCustomer.bind("<Enter>",Back_New_Customer_e)
        BackNewCustomer.bind("<Leave>",Back_New_Customer_l)
  



        global addedsuccessfully
        addedsuccessfully=Label(NewCustomer_Canvas,text="",bg="white",fg="white",font="roboto 11 bold")
        addedsuccessfully.place(relx=.5,rely=.85,anchor=CENTER)



        mainloop()








   

    specialfont=Font(family="Bebas Neue",size=20,weight="normal")



    '''Mid_Canvas=Canvas(root,height=y*0.9,width=x*0.49,bg="black",highlightthickness=0)
    Mid_Canvas.place(relx=.5,rely=.5,anchor=CENTER)'''


    StudentRecord=Button(root,text="Customer Record",width=27,font=specialfont,bg="black",fg="white",highlightbackground="black",highlightthickness=5,cursor=mainscreenselectcursor)
    StudentRecord.place(relx=.5,rely=.43,anchor=CENTER)
    StudentRecord.bind('<Button-1>',sp)
    StudentRecord.bind('<Return>',sp)







    



    NewAdmission=Button(root,text="Add Record",width=27,font=specialfont,bg="black",fg="white",highlightbackground="black",highlightthickness=5,cursor=mainscreenselectcursor)
    NewAdmission.place(relx=.5,rely=.52,anchor=CENTER)
    NewAdmission.bind("<Button-1>", NewSAdmission)
    NewAdmission.bind('<Return>', NewSAdmission)



    Upload_to_Website_Button=Button(root,text="Upload To Website",width=27,font=specialfont,bg="black",fg="white",highlightbackground="black",highlightthickness=5,cursor=mainscreenselectcursor)
    Upload_to_Website_Button.place(relx=.5,rely=.61,anchor=CENTER)
    Upload_to_Website_Button.bind("<Button-1>", send_data_to_github)
    Upload_to_Website_Button.bind('<Return>', send_data_to_github)





    # Button Bind
    StudentRecord.bind("<Enter>",StudentRecord_e)
    StudentRecord.bind("<Leave>",StudentRecord_l)

    NewAdmission.bind("<Enter>",NewAdmission_e)
    NewAdmission.bind("<Leave>",NewAdmission_l)
    


    Upload_to_Website_Button.bind("<Enter>",Upload_to_Website_e)
    Upload_to_Website_Button.bind("<Leave>",Upload_to_Website_l)
























    

    update_date()
    update_time()

# Main Window Loop
    root.mainloop()

   




