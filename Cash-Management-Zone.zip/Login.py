from tkinter import *
from tkinter import ttk
from App import opentheapp
from tkinter import messagebox
import pygame
from tkinter.font import Font
import smtplib
from tendo import singleton
from win32event import CreateMutex
from win32api import CloseHandle, GetLastError
from winerror import ERROR_ALREADY_EXISTS
import sys









def Errormessage():
    def errorclose(e):
        Warningmessage.destroy()

    def OKbutton_e(e):
        OKbutton["bg"]="white"
        OKbutton["fg"]="black"

    def OKbutton_l(e):
        OKbutton["bg"]="black"
        OKbutton["fg"]="white"
    

    






    Warningmessage= Tk()
    Warningmessage.title("Lone Wolf Violation")
    Warningmessage.resizable(False, False)
    Warningmessage.geometry("300x150")
    Warningmessage.configure(bg="black")
    Warningmessage.eval('tk::PlaceWindow . center')
    Warningmessage.iconbitmap("Images//Warning2.ico")
    pygame.mixer.init()
    pygame.mixer.music.load("Sounds//error_message.mp3")
    pygame.mixer.music.play()


    

    errorlabelfont=Font(family="Bebas Neue",size=11,weight="normal")
    errorlabel=Label(Warningmessage, text ='Failed to start (App already running)', font = errorlabelfont,fg="white",bg="black") 
    errorlabel.place(relx=.5,rely=.5,anchor=CENTER)
    OKbutton=Button(Warningmessage, text ='OK', font = errorlabelfont ,fg="white",bg="black",width=9,cursor="hand2")
    OKbutton.place(relx=.5,rely=.85,anchor=CENTER) 
    OKbutton.bind("<Button-1>", errorclose)
    OKbutton.bind('<Return>', errorclose)
    OKbutton.bind("<Enter>",OKbutton_e)
    OKbutton.bind("<Leave>",OKbutton_l)

    Warningmessage.mainloop()











class singleinstance:
    """ Limits application to single instance """

    def __init__(self):
        self.mutexname = "testmutex_{D0E858DF-985E-4907-B7FB-8D732C3FC3B9}"
        self.mutex = CreateMutex(None, False, self.mutexname)
        self.lasterror = GetLastError()
    
    def alreadyrunning(self):
        return (self.lasterror == ERROR_ALREADY_EXISTS)
        
    def __del__(self):
        if self.mutex:
            CloseHandle(self.mutex)



myapp = singleinstance()

# check is another instance of same program running

if myapp.alreadyrunning():
    Errormessage()
    sys.exit(1)

    



pygame.mixer.init()

Application_Password="123"



def endwrongpass():
    wrongpass.configure(text="",fg="black")



def loginaccess(e):
    if entrylabel1.get()==Application_Password:
        pygame.mixer.music.load("Sounds//Access_Granted.mp3")
        pygame.mixer.music.play()

        
        entrylabel1.after(2500,root.destroy())
        entrylabel1.after(6000,opentheapp())
    
    elif(entrylabel1.get()==""):
        pygame.mixer.music.load("Sounds//Access_Denied.mp3")
        pygame.mixer.music.play()
        wrongpass.configure(text="Access Denied",fg="red")
        wrongpass.after(1300,endwrongpass)
    

    else:
        pygame.mixer.music.load("Sounds//Access_Denied.mp3")
        pygame.mixer.music.play()
                
        entrylabel1.delete(0,END)
        wrongpass.configure(text="Access Denied",fg="red")
        wrongpass.after(1300,endwrongpass)
        



def exit_application(e):
    msg_box = messagebox.askquestion('Exit Application', 'Are you sure you want to exit the application?',icon='warning')
    if msg_box == 'yes':
        root.destroy()
    else:
        pass




root =  Tk()
root.wm_attributes('-fullscreen', 'True')
root.title("esports Gaming Zone")
root.iconbitmap("Images//esportsicon.ico")
cursorpath="@Cursors//mainscreencursor.cur"
root[ 'cursor' ] = cursorpath

Buttoncursor="@Cursors//mainscreenselectcursor.cur"
Entrycursor="@Cursors//Entryselect.cur"


width = 1200 # Width 
height = 800 # Height

w=width
h=height
screen_width = root.winfo_screenwidth()  # Width of the screen
screen_height = root.winfo_screenheight() # Height of the screen



x = (screen_width/2) - (width/2)
y = (screen_height/2) - (height/2)

middlecanvas=x*2.2

sidecanvas=width-middlecanvas
newsidecanvas=sidecanvas/2

anothernewidcanvas=newsidecanvas+60
new=y*2
new2=x*2.2








# Background Image
img=PhotoImage(file="Images//New 2.png")
Background=Label(root,image=img,bd=0)
Background.place(relx=0,rely=.045,anchor=NW)

bgcolorforwidgets="black"




titlebarcanvas=Canvas(root,width=1920,height=60,bg="black",highlightthickness=0)
titlebarcanvas.place(relx=0,rely=0,anchor=NW)



  




Centerscreencanvas=Frame(root,width=500,height=250,bg="black",bd=0,highlightthickness=4,highlightbackground="grey40")
Centerscreencanvas.place(relx=.5,rely=.5,anchor=CENTER)





#Button Animations

def close_button_e(e):
    closebutton["bg"]="red"
    closebutton["fg"]="white"


def close_button_l(e):
    closebutton["bg"]="black"
    closebutton["fg"]="white"


def re_button_e(e):
    rebutton["bg"]="grey40"
    rebutton["fg"]="white"

def re_button_l(e):
    rebutton["bg"]="black"
    rebutton["fg"]="white"


def resizable():
    root.iconify()

def resi(e):
    root.after(300,resizable)

rebutton=Button(titlebarcanvas,text="-",fg="white",bg="black",width=3,bd=0,font=("Arial 14  "),cursor=Buttoncursor)
rebutton.place(relx=.978,rely=0.04,anchor=NE)
rebutton.bind("<Button-1>",resi)
rebutton.bind('<Return>',resi)



rebutton.bind("<Enter>",re_button_e)
rebutton.bind("<Leave>",re_button_l)



global closebutton
closebutton=Button(titlebarcanvas,text="x",fg="white",bg="black",width=3,bd=0,font=("Arial 14  "),cursor=Buttoncursor)
closebutton.place(relx=0.999,rely=0.04,anchor=NE)
closebutton.bind("<Button-1>",exit_application)
closebutton.bind('<Return>',exit_application)
  




closebutton.bind("<Enter>",close_button_e)
closebutton.bind("<Leave>",close_button_l)


authentication_font=Font(family="Bebas Neue",size=25,weight="bold")
Authenticationrequired=Label(titlebarcanvas,text="Authentication Required",fg="white",bg="black",font=authentication_font)

Authenticationrequired.place(relx=.5,rely=0.5,anchor=CENTER)

























Pass_entry_font=Font(family="Bebas Neue",size=20,weight="normal")


Enterpass=Label(Centerscreencanvas,text="ENTER PASSWORD",font=Pass_entry_font,fg="white",bg="black")
Enterpass.place(relx=.5,rely=.3,anchor=CENTER)




img2=PhotoImage(file="Images//lock.png")
Background=Label(Centerscreencanvas,image=img2,bd=0)
Background.place(relx=.12,rely=.5,anchor=CENTER)


entrylabel1=Entry(Centerscreencanvas,width=30,font=("roboto 14 bold"),show="•",bd=2,cursor=Entrycursor)
entrylabel1.configure(fg="white",bg="black",insertbackground="white")

entrylabel1.place(relx=.5,rely=.5,anchor=CENTER)
entrylabel1.focus_set()
entrylabel1.bind('<Return>', loginaccess)











def buttonlogin_e(e):
    buttonlogin["bg"]="white"
    buttonlogin["fg"]="black"

def buttonlogin_l(e):
    buttonlogin["bg"]="black"
    buttonlogin["fg"]="white"


Button_font=Font(family="Bebas Neue",size=15,weight="normal")
buttonlogin=Button(Centerscreencanvas,text="LOGIN",width=8,font=Button_font,bg="black",fg="white",bd=2,cursor=Buttoncursor)
buttonlogin.place(relx=.5,rely=.8,anchor=S)
buttonlogin.bind("<Button-1>", loginaccess)
buttonlogin.bind('<Return>', loginaccess)
    




buttonlogin.bind("<Enter>",buttonlogin_e)
buttonlogin.bind("<Leave>",buttonlogin_l)







wrongpass_font=Font(family="Bebas Neue",size=14,weight="normal")
wrongpass=Label(Centerscreencanvas,text="",fg="black",bg="black",font=wrongpass_font)
wrongpass.place(relx=.5,rely=.9,anchor=CENTER)






root.mainloop()















































